Songs downloaded from:

https://sites.google.com/site/wyzplayer/downloads